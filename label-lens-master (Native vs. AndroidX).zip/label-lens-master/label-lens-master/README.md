# Label Lens


### Android App

#### TODO

- Create method to upload data from phone 
- Setup backend to store data as (Image, Label)
- use Camera2 to capture image
- Create GUI for drawing boxes overlayed on captured image 
- Make an API to get labeled data off backend 
