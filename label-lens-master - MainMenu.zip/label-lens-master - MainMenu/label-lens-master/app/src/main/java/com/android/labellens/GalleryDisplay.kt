package com.android.labellens

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

// TODO: Rename parameter arguments, choose names that match


/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [gallery_display.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [gallery_display.newInstance] factory method to
 * create an instance of this fragment.
 */
class GalleryDisplay() : Fragment(), Parcelable {
    constructor(parcel: Parcel) : this() {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {

    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<GalleryDisplay> {
        override fun createFromParcel(parcel: Parcel): GalleryDisplay {
            return GalleryDisplay(parcel)
        }

        override fun newArray(size: Int): Array<GalleryDisplay?> {
            return arrayOfNulls(size)
        }
    }

}

