package com.android.labellens

import android.os.Bundle
import android.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.findNavController
import kotlin.system.exitProcess


/**
 * A simple [Fragment] subclass.
 */
class MainMenu : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val returning =  inflater.inflate(R.layout.fragment_main_menu, container, false)

        val goToLabelButton = returning.findViewById<Button>(R.id.labelButton)
        goToLabelButton.setOnClickListener() {view: View ->
            view.findNavController().navigate(R.id.action_mainMenu_to_labelDisplay)
        }

        val goToCameraButton = returning.findViewById<Button>(R.id.takePhotoButton)
        goToCameraButton.setOnClickListener() {view: View ->
            view.findNavController().navigate(R.id.action_mainMenu_to_cameraDisplay2)
        }

        val goToGalleryButton = returning.findViewById<Button>(R.id.galleryButton)
        goToCameraButton.setOnClickListener() {view: View ->
            view.findNavController().navigate(R.id.action_mainMenu_to_galleryDisplay)
        }

        val exitButton = returning.findViewById<Button>(R.id.exitButton)
        exitButton.setOnClickListener() {
            exitProcess(1)
        }

        return returning.rootView
    }


}
