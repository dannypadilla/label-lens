package com.example.mainmenu

import android.app.Fragment

class CameraDisplay : Fragment() {

}
