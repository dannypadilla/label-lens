package com.example.mainmenu

import android.os.Bundle
import android.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import kotlin.system.exitProcess


/**
 * A simple [Fragment] subclass.
 */
class MainMenu : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val returning =  inflater.inflate(R.layout.fragment_main_menu, container, false)

        val goToLabelButton = returning.findViewById<Button>(R.id.labelButton)
        goToLabelButton.setOnClickListener() { view: View ->
            val frag = LabelDisplay()
            val manager = fragmentManager
            val frag_transaction = manager.beginTransaction()

            frag_transaction.replace(R.id.frag_container, frag)
            frag_transaction.commit()
        }

        val goToCameraButton = returning.findViewById<Button>(R.id.takePhotoButton)
        goToCameraButton.setOnClickListener() {view: View ->
            val frag = CameraDisplay()
            val manager = fragmentManager
            val frag_transaction = manager.beginTransaction()

            frag_transaction.replace(R.id.frag_container, frag)
            frag_transaction.commit()        }

        val goToGalleryButton = returning.findViewById<Button>(R.id.galleryButton)
        goToCameraButton.setOnClickListener() {view: View ->
            val frag = GalleryDisplay()
            val manager = fragmentManager
            val frag_transaction = manager.beginTransaction()

            frag_transaction.replace(R.id.frag_container, frag)
            frag_transaction.commit()        }

        val exitButton = returning.findViewById<Button>(R.id.exitButton)
        exitButton.setOnClickListener() {
            exitProcess(1)
        }

        return returning.rootView
    }


}
