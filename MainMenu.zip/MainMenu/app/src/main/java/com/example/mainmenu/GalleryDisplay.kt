package com.example.mainmenu

import android.app.Fragment

class GalleryDisplay() : Fragment(){

}

